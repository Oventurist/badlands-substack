---
name: Archive Modernist
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#1e1200'
  on-tertiary: '#ffffff'
  tertiary-container: '#35260c'
  on-tertiary-container: '#a38c6a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#fadfb8'
  tertiary-fixed-dim: '#ddc39d'
  on-tertiary-fixed: '#271902'
  on-tertiary-fixed-variant: '#564427'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  deep-slate: '#0F172A'
  link-blue: '#2563EB'
  border-subtle: '#E2E8F0'
  surface-card: '#FFFFFF'
  text-body: '#334155'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-width: 280px
  max-content-width: 840px
  gutter: 32px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 40px
---

## Brand & Style

The design system establishes a tone of **authoritative clarity** and **academic rigor**. It is designed for the "Badlands Wiki," a platform that functions as both a modern knowledge base and a digital news archive. The visual language balances the intellectual heritage of traditional encyclopedias with the efficiency of high-end technical documentation.

The chosen style is **Modern Corporate / Digital Archive**. It prioritizes high information density without sacrificing legibility. The aesthetic is clean and structured, utilizing a crisp grid, purposeful whitespace, and a sophisticated contrast between sharp sans-serif navigation and scholarly serif body text. This evokes a sense of reliability and investigative depth, moving away from the "default" wiki look toward a bespoke, premium editorial experience.

## Colors

The palette is rooted in **Deep Slate** and **Navy**, providing a professional and stable foundation. 

- **Primary (Deep Slate):** Used for primary headings, sidebar titles, and heavy navigation elements to ground the interface.
- **Secondary (Slate Gray):** Used for metadata, counts (e.g., "(369)"), and secondary labels to maintain hierarchy.
- **Neutral (Off-White/Cool Gray):** The main background is a very light cool gray (`#F8FAFC`) to reduce eye strain compared to pure white, while card surfaces remain white to pop forward.
- **Accent (Link Blue):** A focused, high-contrast blue is reserved strictly for interactive text and actionable links within the wiki body.

## Typography

The typographic strategy employs a **dual-font system** to distinguish between the "Interface" and the "Content."

- **Headlines & Interface (Hanken Grotesk):** A sharp, contemporary sans-serif used for navigation, sidebars, buttons, and section headers. It provides a technical, "engineered" feel to the platform's structure.
- **Body & Prose (Source Serif 4):** A highly legible serif designed for long-form reading. This gives the wiki its "encyclopedia" soul, making the dense information feel like a published record.
- **Hierarchy:** Dramatic scale is used for page titles (`display-lg`) to provide immediate orientation. Body text uses a generous `1.8x` line-height to ensure maximum readability in dense articles.

## Layout & Spacing

This design system utilizes a **refined fixed-fluid hybrid grid** typical of high-end documentation.

- **Sidebar:** A fixed 280px left sidebar houses the "Entities" and "Concepts" tree. It uses tight vertical spacing (`stack-sm`) to manage hundreds of links efficiently.
- **Content Area:** A centered container with a maximum width of 840px ensures line lengths remain optimal for reading (approx. 75-85 characters).
- **Responsive Behavior:** 
  - **Desktop (>1024px):** Three-column layout (Sidebar | Content | Table of Contents).
  - **Tablet (768px - 1023px):** Sidebar collapses into a hamburger menu; content fills width with 32px margins.
  - **Mobile (<767px):** Single column with 16px margins; typography scales down slightly.

## Elevation & Depth

The system uses **Tonal Layering** rather than heavy shadows to indicate hierarchy, maintaining a flat, archival aesthetic.

- **Base Layer:** The site canvas uses a subtle cool gray (`#F8FAFC`).
- **Surface Layer:** Main content cards and the search bar use a pure white background with a very fine, low-contrast border (`#E2E8F0`). 
- **Floating Elements:** Only the Search Modal and mobile menus utilize a soft, ambient shadow (10% opacity, 20px blur) to indicate they are temporary overlays.
- **Navigation:** The header uses a backdrop-blur (glassmorphism) effect when scrolling to maintain context without visually obstructing the content beneath it.

## Shapes

The shape language is **Soft and Precise**. 

- **Standard Radius:** A consistent 0.25rem (4px) radius is applied to buttons, input fields, and small UI components to keep the interface looking modern but disciplined.
- **Large Radius:** Content cards and the search container use a 0.5rem (8px) radius to distinguish them as primary structural containers.
- **Interactive Elements:** Hover states for list items in the sidebar use a subtle 4px rounded background highlight.

## Components

- **Search Bar:** A prominent, wide input with a "Command-K" indicator. It should feel like the primary entry point to the system.
- **Sidebar Links:** High-density text links with a left-accent border on active states. Uses `label-md` typography.
- **Content Cards:** Minimalist containers with a 1px border. No shadows. Used for the "Explore the knowledge graph" callout and navigation footers.
- **Buttons:**
  - *Primary:* Solid Deep Slate background, white text, 4px radius.
  - *Ghost:* No background, Navy text, appears on hover with a subtle gray fill.
- **Chips/Badges:** Used for counts next to categories (e.g., "369"). Small, semi-transparent slate background with bold, condensed text.
- **Lists:** Bulleted lists in the body use the serif font and increased vertical padding to distinguish from navigation lists.